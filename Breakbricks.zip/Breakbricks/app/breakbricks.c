/*
 * breakbricks.c
 *
 *  Created on: Feb 12, 2024
 *      Author: Nirgal
 */
#include "config.h"
#include "breakbricks.h"
#include "button.h"
#include "display.h"
#include "stdbool.h"
#include "stm32g4_systick.h"
#include "stm32g4_utils.h"
#include "display.h"
#include  "stm32g4_systick.h"

//Definitions de macros (constantes)
#define DEFAULT_RACKET_SPEED 6
#define  REFRESH_PERIOD_MS 30

//Variables (priv�es, car elles doivent toutes etre prives)


static ball_t ball; // variable privee de la balle

static racket_t racket;  //variable prive de la racket

static grid_t grid;

static bool flag_refresh = false; // variable qui definit si l'ecran a ete rafraichi ou pas

//Protypes de fonctions prives
static void BREAKBRICKS_process_ms(void);
static void BREAKBRICKS_racket_update(bool button_left, bool button_right);
static void BREAKBRICKS_ball_update(bool button_center);
static void BREAKBRICKS_check_collision(void);





//Fonctions publiques

void BREAKBRICKS_init(void)
{
	BUTTONS_init();
	DISPLAY_init();
	BSP_systick_add_callback_function(&BREAKBRICKS_process_ms);

	// on initialise les caracteristiques de la ball
	ball.size = 10;
	ball.x = SCREEN_WIDTH/2;
	ball.y = 40;
	ball.fine_x = ball.x << 3;
	ball.fine_y = ball.y << 3;
	ball.speed_x = 0;
	ball.speed_y = -30;
	ball.joker = 0;
	ball.options = BALL_OPTION_GLUE;

	// same pour la racket

	racket.x = SCREEN_WIDTH/2;
	racket.y = 10 ;
	racket.width = 50;
	racket.height = 10;
	racket.speed = 0;

	// same pour la grille de brique

	grid.bricks[0] = (brick_t){BRICKSTYLE_FULL, 100,220,165,185};
	grid.bricks[1] = (brick_t){BRICKSTYLE_FULL, 110,210,190,210};
	grid.bricks[2] = (brick_t){BRICKSTYLE_FULL, 120,200,215,235};
	grid.nb_bricks_remaining = 3;


}


void BREAKBRICKS_process_main(void)
{
    bool button_left   = BUTTON_left_read();
    bool button_right  = BUTTON_right_read();
    bool button_center = BUTTON_center_read();

    if(button_left)
        HAL_GPIO_WritePin(LED_GREEN_GPIO, LED_GREEN_PIN, GPIO_PIN_SET);

    if(button_right)
        HAL_GPIO_WritePin(LED_GREEN_GPIO, LED_GREEN_PIN, GPIO_PIN_RESET);

    if(flag_refresh){
 // on rafraichi l'ecran uniquement lorsque flag_refresh est sur TRUE.
 // Comme flag_refresh est remise a TRUE
    flag_refresh = false;
    BREAKBRICKS_ball_update(button_center);
    BREAKBRICKS_racket_update(button_left, button_right);

    BREAKBRICKS_check_collision();

    DISPLAY_refresh_ball(&ball);
    DISPLAY_refresh_racket(&racket);
    DISPLAY_refresh_grid(&grid);

    }
}



//Fonctions privées

static void BREAKBRICKS_process_ms(void)
{
	int8_t t;
	if (t < REFRESH_PERIOD_MS -1){
		t+=1;
	}
	else{
		t = 0 ;
		flag_refresh = TRUE;
	}

}


static void BREAKBRICKS_racket_update(bool button_left, bool button_right)
{
	if (button_left){
		racket.speed = -DEFAULT_RACKET_SPEED;
	}
	else if (button_right){
		racket.speed = +DEFAULT_RACKET_SPEED;
	}
	else{
		racket.speed = 0;
	}
	racket.x += racket.speed;
	if (racket.x < racket.width/2){
		racket.x = racket.width/2;  // on gere les collisions avec le mur gauche
	}
	if (racket.x >  SCREEN_WIDTH - racket.width / 2){ // same mais avec le mur de droite
		racket.x = SCREEN_WIDTH - racket.width/2 ;
	}
}

static void BREAKBRICKS_ball_update(bool button_center)
{
	   ball.fine_x += ball.speed_x;
	   ball.fine_y += ball.speed_y;
	   ball.x = ball.fine_x >> 3;
	   ball.y = ball.fine_y >> 3;

	  // On s assure �galement que la balle ne peut pas sortir de l �cran :
	      if (ball.x < ball.size / 2)
	       ball.x = ball.size / 2;

	      if (ball.x > SCREEN_WIDTH - ball.size / 2)
	       ball.x = SCREEN_WIDTH - ball.size / 2;

	      if (ball.y < ball.size / 2)
	       ball.y = ball.size / 2;

	      if (ball.y > SCREEN_HEIGHT - ball.size / 2)
	       ball.y = SCREEN_HEIGHT - ball.size / 2;
}


static void BREAKBRICKS_check_collision(void)
{
	//Contact plafond
	if (ball.y + ball.size / 2 >= SCREEN_HEIGHT)
	ball.speed_y = -ball.speed_y;
	//Contacts murs lat�raux
	if ((ball.x - ball.size / 2 <= 0) || (ball.x + ball.size / 2 >= SCREEN_WIDTH - 1))
	ball.speed_x = -ball.speed_x;
	//Contact avec le sol
	if(ball.y - ball.size / 2 <= 0)
	ball.speed_y = -ball.speed_y;

	//Contact avec la raquette
	 if ( ball.y - ball.size / 2 < racket.y + racket.height / 2 + 1
	   && ball.x + ball.size / 2 >= racket.x - racket.width / 2 - 1
	   &&  ball.x - ball.size / 2 <= racket.x + racket.width / 2 + 1)
	 {
	//pour ne pas entrer en conflit avec la raquette !
	  ball.y = (int16_t)(racket.y + racket.height / 2 + ball.size / 2 + 1);
	  ball.speed_y = -ball.speed_y;

	  //calcul de la ball.speed_x en fonction du point de contact avec la raquette
	  int16_t percentage = (int16_t)((ball.x - racket.x) * 100 / racket.width);
	  ball.speed_x = percentage;
	 }
}

